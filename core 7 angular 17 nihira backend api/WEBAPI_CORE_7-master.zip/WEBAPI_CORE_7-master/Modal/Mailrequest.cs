﻿namespace LearnAPI.Modal
{
    public class Mailrequest
    {
        public string Email { get; set; }
        public string Subject { get; set; }
        public string Emailbody { get; set; }
    }
}
