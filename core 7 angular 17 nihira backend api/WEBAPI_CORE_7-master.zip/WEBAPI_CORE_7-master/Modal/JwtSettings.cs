﻿namespace LearnAPI.Modal
{
    public class JwtSettings
    {
        public string securitykey { get; set; }
    }
}
