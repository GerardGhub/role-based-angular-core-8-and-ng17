﻿namespace LearnAPI.Modal
{
    public class Appmenu
    {
        public string code { get; set; }
        public string Name { get; set; }
    }
}
